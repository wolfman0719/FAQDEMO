﻿     クラス情報を取得するサンプル
==========================================================================
1. 添付ファイルに含まれるファイル

ISJ.Utils.xml		クラス情報を取得するルーチン

readme.txt		このファイル


2. セットアップ方法

2.1 ISJ.Utils.xmlのインポート（ISJ.Utilsクラスがインポートされます）

スタジオを開き、任意のネームスペースに移動し、インポートします。
（スタジオのメニューから　ツール→ローカルからインポート　からファイルを選択します
または、ISJ.Utils.xmlをドラッグし、スタジオのエリアでドロップしてもインポートできます）


3. サンプルの実行

3.1 ターミナルから実行

（USERネームスペースにインポートした時の実行例）

USER>do ##class(ISJ.Utils).ClassInfo()
ネームスペースを指定してください : USER
 
Build.DataSample
INFORMATION.SCHEMA.CHECKCONSTRAINTS
INFORMATION.SCHEMA.COLUMNS
INFORMATION.SCHEMA.CONSTRAINTCOLUMNUSAGE
INFORMATION.SCHEMA.CONSTRAINTTABLEUSAGE
INFORMATION.SCHEMA.INDEXES
INFORMATION.SCHEMA.KEYCOLUMNUSAGE
INFORMATION.SCHEMA.PARAMETERS
INFORMATION.SCHEMA.REFERENTIALCONSTRAINTS
INFORMATION.SCHEMA.ROUTINES
INFORMATION.SCHEMA.SCHEMATA
INFORMATION.SCHEMA.STATEMENTCHILDREN
INFORMATION.SCHEMA.STATEMENTLOCATIONS
INFORMATION.SCHEMA.STATEMENTPRIVACTIONS
INFORMATION.SCHEMA.STATEMENTPRIVOBJECTS
INFORMATION.SCHEMA.STATEMENTRELATIONS
INFORMATION.SCHEMA.STATEMENTS
INFORMATION.SCHEMA.TABLECONSTRAINTS
INFORMATION.SCHEMA.TABLES
INFORMATION.SCHEMA.TRIGGERS
INFORMATION.SCHEMA.VIEWCOLUMNUSAGE
INFORMATION.SCHEMA.VIEWS
INFORMATION.SCHEMA.VIEWTABLEUSAGE
ISJ.Class1
ISJ.INVAISUBGET
ISJ.QL2
ISJ.Sample
WebTerminal.Common
WebTerminal.Core
WebTerminal.Engine
WebTerminal.ErrorDecomposer
WebTerminal.Handlers
WebTerminal.Installer
WebTerminal.Router
WebTerminal.StaticContent
WebTerminal.Trace
WebTerminal.Updater
 
... 以下略

と出力されます。

