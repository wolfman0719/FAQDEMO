/*
 * CachePersentG.java
 *
 */
import java.io.*;
import com.intersys.objects.*;

import java.sql.*;

public class CacheQueryPersentG{

    public static void main(String[] args){
    try {

            String           url="jdbc:Cache://localhost:1972/USER";
            String           username="_SYSTEM";  // null for default
            String           password="SYS";  // null for default
            CacheQuery              cq;
            java.sql.ResultSet      rs;
            Database dbconnection = CacheDatabase.getDatabase (url, username, password);
            /* Create a ResultSet */
            System.out.println( "Creating a ResultSet" );
            /* Create a CacheQuery */
            cq = new CacheQuery( dbconnection, "User.TestStoredProc1", "G");
            InputStreamReader isr = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(isr);
            System.out.print("Enter Global Name: ");
            String gn = br.readLine();
            /* Execute the query and loop across the returned rows */
            rs = cq.execute(gn);
            ResultSetMetaData rsmd = rs.getMetaData();

 	    int colnum = rsmd.getColumnCount();
 	    while (rs.next()) {
 		for (int i=1; i<=colnum; i++) {
                   System.out.print(rsmd.getColumnName(i) + "   ");
 		}
 		System.out.println();

                for (int i=1; i<=colnum; i++) {
                    System.out.print(rs.getString(i) + "  ");
                }
                System.out.println();
 	    }

 	    dbconnection.close();
 	} catch (Exception ex) {
 			System.out.println("Caught exception: " +
                               ex.getClass().getName()
                               + ": " + ex.getMessage());
 		}
 	}

}
