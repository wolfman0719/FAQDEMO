﻿     ユーザクエリを呼ぶ方法のサンプル
==========================================================================
1. userquerytest.zipに含まれるファイル


TestSP.xml			このサンプル実行に必要なクラス定義
userquerytest.xml		このサンプル実行に必要なクラス定義
CachePersentG.java		Javaサンプル（JDBCストアドプロシジャ）
CacheQueryPersentG.java		Javaサンプル（Java Binding）
readme.txt	このファイル


2. セットアップ方法

2.0　動作バージョン

Cache　V5.1以降

2.1 TestSP.xml,userquerytest.xmlのインポート（クラス）

スタジオにてUSERネームスペースにクラスとしてインポートし、コンパイルしてください。

TestSP.xmlをインポートすると、User.TestStoredProc1クラスがインポートされます。

このクラスには、ユーザコードで記述されたクエリ G が定義されています。
G クエリでは、引数に指定されたグローバル変数名の、
	第1番目のサブスクリプトとそのデータ
を検索し、結果セットオブジェクトとして結果を返します。


3.　実行方法

グローバル変数を作成します。
任意のグローバル変数名で、適当にデータを作成してください。

例）
for i=1:1:10 set ^test(i)="あいうえお"_i


3.1　COSサンプルの実行

>Do ^UserQuerytest()


実行例）

USER>do ^UserQuerytest()
グローバル名を入力 ^test
^test(1) = あいうえお1
^test(2) = あいうえお2
^test(3) = あいうえお3
^test(4) = あいうえお4
^test(5) = あいうえお5
^test(6) = あいうえお6
^test(7) = あいうえお7
^test(8) = あいうえお8
^test(9) = あいうえお9
^test(10) = あいうえお10



3.2 Javaサンプル実行

CLASSPATHにjarファイルを追加します。

jarファイルは、以下のディレクトリにあります。
　＜Cacheインストールディレクトリ＞Dev\java\lib\JDKnn\　ここ


●　V5.1 ～ V5.2
CLASSPATH に以下jarファイルを追加します。
	＜Cacheインストールディレクトリ＞\Dev\java\lib\JDKnn\CacheDB.jar

●　V2007.1　～　V2010.2
CLASSPATH に以下jarファイルを追加します。
	＜Cacheインストールディレクトリ＞\Dev\java\lib\JDKnn\CacheDB.jar

●　V2011.1～
CLASSPATHに 2つのJarファイルを指定します。
	＜Cacheインストールディレクトリ＞\dev\java\lib\JDKnn\CacheDB.jar
	＜Cacheインストールディレクトリ＞\dev\java\lib\JDKnn\cachejdbc.jar

●　V2017.1～
	＜Cacheインストールディレクトリ＞\dev\java\lib\JDKnn\cache-db-2.0.0.jar
	＜Cacheインストールディレクトリ＞\dev\java\lib\JDKnn\cache-jdbc-2.0.0.jar
