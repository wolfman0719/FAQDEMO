﻿複数結果セットの取得例 【Caché／Ensemble／HealthShare版サンプル】

1.　サンプルのセットアップ

1.0　動作バージョン

バージョン2010.2以降

1.1　クラス定義　devcon2008.MultipleResultSetSample.xml　のインポート

スタジオを開き、SAMPLESネームスペースに接続した後
ツール->ローカルからインポートにより　devcon2008.MultipleResultSetSample.xml　を選択し、インポート


2.　Javaサンプルの実行

MultiRS.java

※実行前に、弊社製品のJDBC用JARファイルをClassPathへ登録する必要があります。
　詳しくはドキュメントをご参照ください。
https://docs.intersystems.com/enslatestj/csp/docbook/DocBook.UI.Page.cls?KEY=BGJD_intro#BGJD_intro_packages
