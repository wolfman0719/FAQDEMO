﻿     クラス情報を取得するサンプル　（Caché5.1以降のサンプル）
==========================================================================
1. 添付ファイルに含まれるファイル

classinfo.xml		クラス情報を取得するルーチン

readme.txt		このファイル


2. セットアップ方法

2.1 classinfoルーチンのインポート（ルーチン）

CACHEスタジオにて適当なネームスペースに　
classinfo.xml　をインポートします。（ルーチンが含まれています。）


3. サンプルの実行

3.1 ターミナルから実行

USER>do ^classinfo
ネームスペースを指定してください : samples
 
BasTutorial.Person
Cinema.Duration
Cinema.Film
Cinema.FilmCategory
Cinema.RemoveCookie
Cinema.Show
Cinema.Theater
Cinema.TicketConfirm
Cinema.TicketItem
Cinema.TicketOrder
Cinema.Utils
CosTutorial.Person

... 以下略

と出力されます。

