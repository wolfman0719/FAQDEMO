﻿     ASPからCachéにアクセスするサンプル
==========================================================================
1. yubinasp.zipに含まれるファイル

index.asp		サンプルASP
yubin.asp		サンプルASP
wsd.yubin.xml		サンプル実行に必要なクラス定義
wsd.YUBIND.gsa		サンプル実行に必要なクラスインスタンスデータ
readme.txt		このファイル

2. セットアップ方法

2.0 動作可能Cachéバージョン

Caché5.1以降

2.1 インターネット インフォメーション サービス(IIS)の設定

IISの設定に関しては、Microsoft提供資料等を参照してください。

2.2 was.yubin.xml　クラス定義のインポート

CachéスタジオにてネームスペースUSERにクラスとして
インポート、コンパイルしてください。

2.3 wsd.YUBIND.gsaのインポート（グローバル）

Cachéシステム管理ポータルにてネームスペースUSERにグローバルとして
インポートしてください。

2.4 CacheODBCの設定(デフォルトで設定されているものを使用)


DSN名		Cache User
Namespace	USER
User名		_system
Password	SYS

かならずUser DSNではなくSystem DSNとして設定してください。

2.5　ASPファイルのデプロイ

通常、Inetpub\wwwrootに*.aspファイルを配置

3. サンプルの実行

3.1 ブラウザから実行

http://localhost/index.asp			トップページ

