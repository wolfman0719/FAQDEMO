import com.intersys.xep.*;
	
public class CurrentAge {

		public static void main(String[] args) throws Exception {
		
		EventPersister persister = null;
		persister = PersisterFactory.createPersister();

		persister.connect("localhost",1972,"SAMPLES","_System","SYS");
		System.out.println("Connected to Cache.");
		// $ZD(61900) = 06/23/2010 : %Date�^����
		System.out.println("Return=" + persister.callClassMethod("Sample.Person", "CurrentAge",61900).toString());
		persister.close();
		System.out.println("Finished");
		}
}
