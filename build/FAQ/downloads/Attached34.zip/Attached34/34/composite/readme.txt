﻿
CACHE Objectサンプル

		　　　　				InterSystems Japan
                        					2008/2/29

1.　はじめに

このサンプルは、CACHE　オブジェクトサンプルです。

オブジェクトパターンとして有名なコンポジットパターンをCACHEで実装して
います。

2.　サンプルキットの構成

このキットには以下のファイルが含まれます。

2.1 parties.gif

サンプルに含まれるクラスのクラス図

2.2 party.xml

サンプルに含まれるクラスのCACHEクラス定義

2.3 Printparties.rsa

サンプルに含まれるルーチン

2.4 Sample.PartyD.gsa

サンプル実行に必要なCACHEデータ(グローバル)

2.5 PartyTree.java

Tree Viewに組織階層を表示するサンプル

2.6 Sample\*.java

CACHEクラスのプロキシJavaクラス

3.　インストレーション方法

3.0. 動作可能Cacheバージョン

V5.1以降

3.1. Composite.zipをWinZip等のツールで適当なディレクトリに解凍して下さい。

3.2  Party.xmlをUSERネームスペースにインポート

3.4　PrintParties.rsaをUSERネームスペースにインポート

3.5　Sample.PartyD.gsaをUSERネームスペースにインポート

4.　実行方法

4.1　PrintParties

>Do Printparties()

4.2  PartyTree.java

V5.1 ～ V5.2

CLASSPATH にc:\cachesys\Dev\Java\Lib\JDK**\CacheDB.jarを追加
※** はJDKバージョン

V2007.1 ～ 2016.2.x

CLASSPATH にc:\InterSystems\Cache\Dev\Java\Lib\JDK**\CacheDB.jarを追加

V2017.1
CLASSPATH にc:\InterSystems\Cache\Dev\Java\Lib\JDK**\cache-db-2.0.0.jarを追加

