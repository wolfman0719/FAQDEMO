/*
 * Partybatch.java -- test Cache Java
 *
 */

import java.util.*;
import com.intersys.objects.*;
import com.intersys.classes.*;

/**
 * This is a console program to test out Cache' Java 2.0
 *
 */
public class Partybatch {
    /**
     * The main entry point for the test program
     *
     * @param args Array of parameters passed to the application
     * via the command line.
     */
    public static void main( String[] args )
        throws Exception
    {
        Database         dbconnection = null;
        String           url="jdbc:Cache://localhost:1972/USER";
        String           username="_SYSTEM";  // null for default
        String           password="SYS";  // null for default
        Sample.Party          party = null;
        Sample.Employee       emp = null;
        Sample.Department     dept = null;
        Id              oid = null;
        ListOfDataTypes     rs;

        boolean isQuick = false;
        for (int i = 0; i < args.length; i++)
            if (args[i].equals("-quick"))
                isQuick = true;
            else if (args[i].equals("-oid"))
                oid = new Id (args[++i]);

        try {
            /* Connect to this machine, in the ISJSAMPLES namespace */
            if (isQuick)
                dbconnection = CacheDatabase.getLightDatabase (url, username, password);
            else
                dbconnection = CacheDatabase.getDatabase (url, username, password);


            System.out.println( "Connected." );

            //Sample.Person.checkAllFieldsValid(dbconnection);

            /* Open an instance of the Sample.Party object */
            if (oid == null)
                oid = new Id( 1 );

            rs = new ListOfDataTypes(dbconnection);

            if (!(Sample.Party.exists (dbconnection, oid)))
                {
                    System.out.println ("There is no Party with id " +
                                        oid.toString() + " in the database.");
                    dbconnection.close();
                    return;
                }

            party = (Sample.Party) Sample.Party._open( dbconnection, oid );
            System.out.println("Class Name = " + party._className());
            System.out.println( "BuildNameList." );
            rs = party.BuildNameList(rs);
            System.out.println( "Get the iterator." );
            Iterator rsi = rs.iterator();
            System.out.println( "Decompose the NameList." );
            while (rsi.hasNext()) {
              System.out.println( "Party Name is " + rsi.next() );
            }

            /* un-assign the person object */
            dbconnection.closeObject(party.getOref());
            party = null;
            dept = null;
            /* Close the connection */
            dbconnection.close();
            System.out.println( "Disconnected." );

        } catch (CacheException ex) {
            System.out.println( "Caught exception0: " + ex.getClass().getName() + ": " + ex.getMessage() );
            ex.printFullTrace(System.out);
        } catch (Exception ex) {
            System.out.println( "Caught exception0: " + ex.getClass().getName() + ": " + ex.getMessage() );
            ex.printStackTrace();
        }
    }
}

/*
 * End-of-file
 *
 */

