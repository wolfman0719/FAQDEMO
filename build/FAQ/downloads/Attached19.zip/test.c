#define ZF_DLL 
#include "cdzf.h"

 

extern int mupper();

 

ZFBEGIN
ZFENTRY("UPPER","C",mupper)
ZFEND

 
mupper(string)
    char *string;
    {
    while (*string)
        { if (*string >= 'a' && *string <= 'z')
            *string +='A' - 'a';
        ++string;
        }
        return(0);
    }

